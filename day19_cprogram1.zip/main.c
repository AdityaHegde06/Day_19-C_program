/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#define PI 3.1428

int main()
{
   float r=6.25,area;
   area=PI*r*r;
   printf("Area of circle=%f\n",area);

    return 0;
}
