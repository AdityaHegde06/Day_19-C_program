/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#define AREA(x)(3.14*x*x)
int main()
{
 float r1=6.25,r2=2.5,a;
 a=AREA(r1);
 printf("area of the circle=%f\n",a);
 a=AREA(r2);
 printf("Area of circle=%f\n",a);
 return 0;
}
